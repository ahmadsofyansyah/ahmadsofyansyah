
<?php

$options = [
    'cost' => 12,
];
echo password_hash("ahmadsofyansyah", PASSWORD_BCRYPT, $options);
?>
