
<?php
echo password_hash("Ahmadsofyansyah", PASSWORD_DEFAULT);
?>
