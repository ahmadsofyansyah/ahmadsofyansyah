<?php
echo 'Argon2i hash: ' . password_hash('ahmadsofyansyah', PASSWORD_ARGON2I);
?>
